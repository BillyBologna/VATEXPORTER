# VAT Tool: Maya → Web (Three.js) / Unity / Unreal

Exporta **Vertex Animation Textures** desde Maya y las reproduce en la web o en un motor de videojuegos, sin huesos y con instancias baratas.

```
Maya (vat_exporter.py) ──► texturas + malla + JSON ──► Web  (index.html, Three.js)
                                                   ├─► Unity (VAT_Standard.shader / VAT.hlsl)
                                                   └─► Unreal (VAT_Position.hlsl / VAT_Normal.hlsl)
```

## Contenido del paquete

| Carpeta | Archivo | Para qué sirve |
|---|---|---|
| `maya/` | `vat_exporter.py` | Herramienta con ventana para Maya. Exporta todo. |
| `web/` | `index.html` | Visor Three.js: instancias, PBR, texturas, normal maps, Rigid. |
| `unity/` | `VAT_Standard.shader` | Unity **Built-in RP**. Se asigna a un material. |
| `unity/` | `VAT.hlsl` | Unity **URP/HDRP**, para un Custom Function node de Shader Graph. |
| `unreal/` | `VAT_Position.hlsl`, `VAT_Normal.hlsl` | Código para dos nodos *Custom* de un material de Unreal. |

---

## 1. Exportar desde Maya

1. Abre el **Script Editor** (pestaña Python), pega `vat_exporter.py` completo y ejecútalo. Se abre la ventana.
2. Selecciona la malla (o varias piezas si usas Rigid).
3. Elige **Destino**, revisa las opciones y pulsa **EXPORTAR VAT**.

Requisitos: Maya con Python 3 y `numpy` (ya viene incluido). No necesita librerías extra.

### Opciones de la ventana

| Opción | Qué hace |
|---|---|
| **Destino** | Web, Unity, Unreal o Genérico. Rellena valores por defecto (formato, escala, ejes). |
| **Tipo** | *Soft body*: una malla que se deforma. *Rigid body*: varias piezas que se mueven sin deformarse. |
| **Espacio** | *Mundo*: incluye el movimiento del objeto. *Objeto*: solo la deformación. *Offset*: mundo menos el frame inicial. |
| **Precisión** | Float32 (recomendado) o Float16. Float16 solo con Offset. |
| **Archivos** | `.bin` (web), `.exr` (motores), FBX con UV2, y malla dentro del JSON. |
| **Bordes duros** | Normales por cara. Divide vértices, así que sube el número de filas. |
| **Tangentes** | Para normal maps. |
| **Color / alpha** | Color de vértice por frame (fluidos, efectos). |
| **Frames, paso, tamaño máx.** | Rango a exportar, salto entre frames y tamaño máximo de textura (4096). Si se supera, se parte en tiles. |
| **Escala unidades** | Web 1, Unity 0.01 (cm → m), Unreal 1. |

### Qué espacio elegir

- **Objeto único que se mueve por transform** (tu esfera rebotando): *Mundo*.
- **Muchas copias (instancias)** o mover la malla desde el motor: *Objeto* u *Offset*.
- **Motores con EXR half (Unreal siempre)**: *Offset*, porque las posiciones absolutas pierden precisión.

### Archivos que salen

| Archivo | Contenido | Se usa en |
|---|---|---|
| `nombre_pos.bin` / `.exr` | Posición de cada vértice en cada frame | Web / Motores |
| `nombre_nrm.bin` / `.exr` | Normales | Web / Motores |
| `nombre_tan.*`, `nombre_col.*` | Tangentes y color (opcionales) | Web / Motores |
| `nombre_rot.*` | Rotación por pieza (solo Rigid) | Web / Motores |
| `nombre_vat.json` | Metadatos (y la malla si se activa) | Web; en motores solo lo lees |
| `nombre_vat.fbx` | Malla con **UV2** de lookup | Unity / Unreal |

### Convención de la textura

- Ancho = frames (× tiles). Alto = filas (vértices ya desdoblados por UV y, si aplica, por normal).
- Fila `r`: `v = (r + 0.5) / tile_height`. Con tiles, `u = tile / tiles` en el UV2.
- Los `.exr` se guardan **volteados en vertical** para que el UV2 funcione directo en Unity y Unreal.
- El `.bin` va sin voltear, listo para `THREE.DataTexture`.

### Campos importantes del JSON

| Campo | Significado |
|---|---|
| `frames`, `fps` | Duración y velocidad de reproducción. |
| `vertices` | Filas de la textura (o piezas, en Rigid). |
| `texture` | `[ancho, alto]` de la textura. |
| `tiles`, `tile_height` | Partición horizontal cuando hay demasiadas filas. |
| `position_mode` | `absolute` u `offset`. |
| `space`, `mode`, `target` | Cómo se exportó. |
| `unit_scale`, `up_axis` | Escala aplicada y eje vertical del destino. |
| `bbox_min`, `bbox_max` | Caja de todo el recorrido. |
| `dtype` | `float32` o `float16`. |
| `flip_winding` | `true` si se invirtió el orden de triángulos (Unity y Unreal). |

---

## 2. HDRI de iluminación (carpeta `web/HDRI/`)

El panel tiene un selector **Entorno (HDRI)** que detecta solo los archivos que pongas en `web/HDRI/`, nombrados `01.exr`, `02.exr`, `03.exr`... Como una página web estática (GitHub Pages incluido) no permite "listar" una carpeta, el visor **prueba** `01.exr`, luego `02.exr`, y así hasta el primer número que no exista — por eso basta con subir `10.exr` para que aparezca solo la próxima vez que se abra la página, sin tocar código.

Qué necesitas:

- Archivos `.exr` **equirectangulares** (panorámicos 360°, el formato típico de HDRI de iluminación — los que bajas de [Poly Haven](https://polyhaven.com/hdris) u otro banco, por ejemplo).
- Nombrados en secuencia desde `01.exr`, sin saltos (`01, 02, 03...`; si falta el `03`, el visor se detiene ahí y no revisa el `04` aunque exista).
- Para que la demo cargue rápido, usa versiones livianas (1K–2K, no 4K/8K) — un HDRI de iluminación no necesita tanta resolución como uno que se vaya a ver de fondo nítido.

Cómo se usa: el selector siempre parte en **"Genérico (por defecto)"** (el entorno de estudio que ya traía el visor). Al elegir un HDRI de la carpeta, se usa para iluminar reflejos y el vidrio; la casilla **"Usar también como fondo"** además lo muestra detrás de la escena, en vez del fondo oscuro.

## 2. Abrir directo en el visor web (sin copiar archivos)

En el Paso 7 de la ventana de Maya hay una casilla **"Abrir en visor web tras exportar"**. Actívala y señala la carpeta donde están `index.html` y `vat.js` (la carpeta `web/` de este paquete, o la tuya si ya lo integraste a un proyecto).

Al pulsar **EXPORTAR VAT**, además de generar los archivos ahí mismo, se levanta un servidor local y se abre tu navegador ya apuntando a la animación recién exportada — no hace falta copiar nada a mano ni acordarte de recargar con caché.

Limitaciones honestas de esto:

- Es un atajo de **flujo de trabajo local** (en tu propia máquina), no un despliegue a internet. Para publicar en una web real sigue aplicando lo de la sección siguiente (subir a tu hosting, GitHub Pages, etc.).
- Si la carpeta elegida no tiene `index.html`, Maya avisa y no exporta nada raro.
- El servidor se queda corriendo en segundo plano mientras Maya esté abierto, para no reabrir uno por cada export; se cierra solo al cerrar Maya.

## 2. Web (Three.js)

El paquete trae dos piezas separadas:

- **`vat.js`** — el módulo reusable: carga, reproduce, gestiona instancias, clips y limpieza de memoria. Es lo que usas en tu propio proyecto.
- **`index.html`** — una demo/visor que usa `vat.js`, con un panel de control y un selector para probar varios modelos.

### Probar rápido con datos de ejemplo

`web/sample-data/` trae dos VATs sintéticos (no vienen de Maya) para que veas el visor funcionando antes de exportar nada:

1. Copia los 6 archivos de `sample-data/` a la carpeta `web/` (junto a `index.html` y `vat.js`).
2. Sirve `web/` con un servidor local (`python -m http.server` o GitHub Pages). No funciona con doble clic.
3. Abre `index.html` y usa el selector **Modelo** arriba a la izquierda: una esfera que rebota (`my_mesh_*`, misma estructura que la tuya) y un plano que **se deforma de verdad** vértice a vértice (`wave_*`), para ver el caso que no se había probado con tu esfera.

### Usar tu propio modelo

1. Exporta desde Maya con destino **Web**.
2. Reemplaza los archivos de `sample-data/` (mismo prefijo `my_mesh_*`) o edita el objeto `MODELS` al inicio del `<script>` de `index.html` para apuntar a tus propios nombres.
3. Si ves la versión vieja tras subir archivos nuevos, recarga con `Ctrl+Shift+R`. El visor ya evita la caché en sus peticiones (`vat.js` la desactiva por defecto; pásale `{ cacheBust: false }` si no la quieres).

### `vat.js` en tu propio proyecto

```js
import { loadVAT, checkVATSupport } from './vat.js';

const support = checkVATSupport(renderer);
if (!support.ok) { mostrarAviso(support.reason); }   // dispositivo sin texturas float

const vat = await loadVAT('./personaje', {
  size: 2,                          // tamaño en escena de UNA instancia
  maxInstances: 500,                // reserva de instancias en GPU
  onProgress: (p) => barra.value = p.percent,   // progreso real de descarga
  material: { roughness: 0.4 },     // overrides de MeshStandardMaterial
  clips: {                          // opcional: varias animaciones en la misma textura
    idle: { start: 0,  end: 59 },
    run:  { start: 60, end: 119 },
  },
});
scene.add(vat.object);

vat.play('run', { loop: true, fadeSeconds: 0.25 });
vat.setInstanceCount(200);
vat.randomizePhases();

// en el loop de render:
vat.update(dt);

// al quitarlo de escena:
vat.dispose();
```

Panel de control de la demo:

- **Modelo:** alterna entre los VATs definidos en `MODELS` (o el que pases por `?base=`).
- **Reproducción:** velocidad, pausa y frame.
- **Instancias:** de 1 a 1000, con desfase aleatorio de tiempo.
- **Material:** color, metal, rugosidad, textura de color y normal map (requiere haber exportado tangentes; si no, el campo se deshabilita solo y lo avisa).

### Qué resuelve `vat.js` que la versión anterior no tenía

| Problema | Solución |
|---|---|
| Pantalla negra en dispositivos sin texturas float | `checkVATSupport()` lo detecta antes de cargar nada |
| "Cargando…" fijo sin saber si avanza | `onProgress` con bytes reales vía `fetch().body.getReader()` |
| Mensajes de error técnicos en pantalla | La demo separa el error de consola (para ti) del aviso al usuario |
| Fugas de memoria al cambiar de modelo | `vat.dispose()` libera texturas y geometría de GPU |
| Solo se podía mostrar un modelo a la vez, código duplicado por modelo | `loadVAT()` es una función reusable; la demo carga 2 modelos con el mismo código |
| Una animación por archivo | `clips` + `vat.play(nombre, {fadeSeconds})` para varias animaciones con transición |

### Panel de estadísticas (FPS, memoria, triángulos)

La demo trae un panel en la esquina superior derecha con:

- **FPS** y **tiempo de frame** (ms), promediados sobre los últimos 30 frames.
- **Triángulos** y **draw calls** enviados a la GPU ese frame.
- **Instancias** activas y **texturas** en memoria.
- **JS heap** (memoria de JavaScript; solo en Chrome, vía `performance.memory`).

**Importante:** WebGL no expone el % de uso real de la GPU — ningún sitio web puede leer eso, es una restricción de seguridad del navegador (herramientas como el Administrador de tareas lo leen por acceso al sistema operativo, algo que una página web no tiene). Lo que ves aquí es lo que sí es medible desde el navegador, y es lo mismo que usan los profilers de Three.js en la práctica. Si el FPS es bajo, la causa casi siempre es: demasiadas instancias, texturas muy grandes, o `roughness` muy bajo con muchas luces (el cálculo de reflejos es caro).

### Canales de textura completos (estilo Substance Painter)

El material soporta el set PBR completo, no solo color y normal:

| Canal | Uso |
|---|---|
| Albedo (`map`) | Color base |
| Normal (`normalMap`) | Requiere haber exportado tangentes desde Maya |
| Roughness (`roughnessMap`) | Rugosidad por textura |
| Metalness (`metalnessMap`) | Metal por textura |
| AO (`aoMap`) | Oclusión ambiental (reutiliza el UV existente) |
| Emissive (`emissiveMap`) | Zonas que emiten luz propia |
| Alpha (`alphaMap`) | Transparencia por textura (activa `transparent` solo) |

Cada canal tiene su propio input de archivo en el panel, con un botón **×** para quitarlo. Por código:

```js
vat.setTexture('map', textura, { srgb: true });      // albedo y emissive van en sRGB
vat.setTexture('roughnessMap', textura);              // el resto va en espacio lineal
vat.setTexture('alphaMap', null);                      // quitar un canal
```

### Vidrio y refracción (tipo Arnold Glass / Standard Surface)

El material base es `MeshPhysicalMaterial`, que soporta **transmission** (transparencia física, no solo alpha) e **IOR** (índice de refracción), igual que el Glass BSDF de Arnold o el modo Glass de Substance Painter:

```js
vat.setGlass({ transmission: 1, ior: 1.5, thickness: 0.5, roughness: 0.05 });
// vidrio:   ior ~1.45-1.55
// agua:     ior ~1.33
// diamante: ior ~2.4
vat.setGlass({ transmission: 0 });   // desactivar
```

En el panel: casilla **Activar** + sliders de transmisión, IOR y grosor. Para que el efecto se note, la escena necesita un entorno que refractar — la demo ya trae un `RoomEnvironment` de fondo para esto.

**Nota técnica** (por si extiendes el material): `MeshPhysicalMaterial` define `STANDARD` y `PHYSICAL` en su propio `material.defines` al construirse. Si necesitas tocar `material.defines`, **agrega** claves (`mat.defines.MI_FLAG = ''`) en vez de reasignar el objeto completo (`mat.defines = {...}`) — reasignarlo borra esos dos defines base y el modo vidrio falla en silencio hasta que lo activas, con un error de compilación de shader poco claro. Ya está resuelto en `vat.js`, pero es un error fácil de reintroducir.

### Transparencia simple

Para transparencia por alpha corriente (sin refracción física), usa el slider de **Opacidad** o `vat.material.opacity` + `vat.material.transparent = true`.

---

## 3. Unity

Exporta con destino **Unity**: genera `.exr` (float32), el FBX y el JSON.

### Importar las texturas (`_pos.exr`, `_nrm.exr`)

| Ajuste | Valor |
|---|---|
| sRGB (Color Texture) | **Off** |
| Generate Mip Maps | **Off** |
| Filter Mode | **Point** |
| Compression | **None** |
| Wrap Mode | Clamp |
| Format | RGBA 32 bit float (o RGBA Half si exportaste Float16) |

### Built-in RP

1. Importa `nombre_vat.fbx`. El FBX trae dos juegos de UV: el segundo (UV2) es el lookup. Desactiva *Generate Lightmap UVs* si no lo necesitas.
2. Crea un material con el shader **VAT/Standard**.
3. Asigna `_PosTex` y `_NrmTex`, y copia del JSON: `_Frames` (= `frames`), `_TexW` (= `texture[0]`), `_Tiles` (= `tiles`) y `_Fps` (= `fps`).
4. Activa `_OffsetMode` si `position_mode` es `offset`.
5. Activa **Enable GPU Instancing** en el material.
6. Para desfasar cada instancia, pon un valor distinto de `_Phase` con `MaterialPropertyBlock`.

### URP / HDRP (Shader Graph)

1. Crea un Custom Function node → Type **File** → Source `VAT.hlsl` → Name **VAT**.
2. Inputs, en este orden: PosTex, NrmTex, UV2, Frame, Frames, TexW, Tiles, OffsetMode, VertexPos.
3. `UV2` es el nodo *UV* con canal **UV1**. `VertexPos` es el nodo *Position* en Object.
4. `Frame = Time × Fps × Speed + Phase`. Conéctalo con nodos normales.
5. Las salidas Position y Normal van a **Vertex Position** y **Vertex Normal** (Object space).

---

## 4. Unreal Engine

Exporta con destino **Unreal**, modo **Offset**: los EXR entran a 16 bits en Unreal, y las posiciones absolutas perderían precisión.

### Importar las texturas

| Ajuste | Valor |
|---|---|
| Compression Settings | **HDR (RGBA16F, sin compresión)** |
| Mip Gen Settings | **NoMipmaps** |
| sRGB | **Off** |
| Filter | **Nearest** |
| Never Stream | **On** |

### Importar el FBX

- Static Mesh, **sin Nanite**.
- Activa **Use Full Precision UVs** en Build Settings, para no perder precisión en el UV2.
- Desactiva *Generate Lightmap UVs*, para que no sobrescriba el UV2.
- Amplía los **Extended Bounds** del mesh: la animación mueve los vértices y, si no, el culling puede ocultarlo.

### Material

1. Añade una expresión **Custom** con el código de `VAT_Position.hlsl` (Output Type *Float 3*). Inputs con los mismos nombres del archivo: `PosTex` (Texture Object), `UV2` (TextureCoordinate, índice 1), `Frame`, `Frames`, `TexW`, `Tiles`.
2. `Frame = Time × Fps × Speed + PerInstanceRandom × Frames`. `Frames`, `TexW` y `Tiles` salen del JSON.
3. La salida pasa por **Transform Vector (Local → World)** y va a **World Position Offset**.
4. Repite con `VAT_Normal.hlsl` y `NrmTex`. Pasa el resultado por un **Vertex Interpolator**, transfórmalo a mundo y conéctalo a **Normal**, con *Tangent Space Normal* desactivado en el material.
5. Usa el material con Instanced Static Mesh o HISM para tener instancias.

---

## 5. Verificar los ejes (recomendado)

Los ejes de Unity `(-x, y, z)` y Unreal `(x, z, y)` están derivados de las convenciones de cada motor. Están comprobados matemáticamente, pero **no contra el motor real**. Compruébalo una vez:

1. En Maya, selecciona el destino y pulsa **Crear test de ejes**. Genera un objeto asimétrico animado, su VAT y `axis_test_ref.fbx`, una referencia estática del frame 15.
2. En el motor, pon el material con `_OffsetMode` **desactivado** y el tiempo fijo en el frame 15.
3. Coloca junto a él el FBX de referencia, con el mismo origen. Deben **superponerse**.
4. Si aparecen espejados, girados o desplazados, avísame con una captura para ajustar la matriz de ejes de ese motor.

---

## 6. Problemas frecuentes

| Síntoma | Causa probable |
|---|---|
| La malla no se mueve en la web | Archivos viejos en caché, o se exportó en Objeto un movimiento hecho con transform. Usa Mundo. |
| En Maya, "Movimiento máx = 0" | La animación no afecta esa malla, o falta evaluar. El script ya desactiva el Evaluation Manager. |
| Vértices que tiemblan | Float16 con posiciones absolutas. Usa Float32 u Offset. |
| Malla enorme o diminuta en Unity | Falta la escala 0.01, o el material no coincide con el FBX (unidades). |
| Malla espejada o girada | Ejes del motor. Haz el test de ejes. |
| Caras invertidas | Se invirtió el winding en Unity y Unreal. Si aún se ve mal, activa *Two Sided* en el material. |
| Error de textura demasiado ancha | Frames × tiles supera el máximo. Sube el paso, baja los frames o aumenta el tamaño máximo. |
| Artefactos entre el último y el primer frame | La interpolación cierra el bucle. Si tu animación no es cíclica, corta un frame. |

---

## 7. Estado y pendientes

**Probado:** el exportador soft body con tu esfera en Maya y el visor web. La lógica del resto del script (tiles, offset, bordes duros, tangentes, color, Rigid, EXR y ejes) se probó con una simulación de la API de Maya, no con Maya real.

**Sin probar en el motor real:** los shaders de Unity, los nodos de Unreal y el FBX con UV2. El código sigue las convenciones de cada motor, pero verifica con una malla sencilla antes de usarlo en producción.

**Ideas para más adelante:**

- Shader Graph y material de Unreal ya montados (archivos `.shadergraph` y `.uasset`) en lugar de código.
- Rigid body en Unity y Unreal, con su propio shader.
- Compresión de los `.bin` para web (float16 por defecto, o cuantización).
- Múltiples animaciones (clips) en una misma textura.
- Blending entre animaciones.
- GLB con la malla y UV2 para web.
- LOD de animación (menos frames en objetos lejanos).
